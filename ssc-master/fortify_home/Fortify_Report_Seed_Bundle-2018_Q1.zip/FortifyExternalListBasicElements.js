extListUtil = new Object();

var nistControl; // forward declaration - see actual definition at bottom. 
/**
 * The functions in this array will return the group name for the given category
 */
extListUtil.groupNameFunctions = new Object();
extListUtil.groupNameFunctions["SANS"] = function(category) { return util.getFirstMatchGroup(/(.*) - CWE ID .*/, category); }
extListUtil.groupNameFunctions["STIG"] = function(category) { return util.getFirstMatchGroup(/AP.* (CAT II?I?)/, category); }
extListUtil.groupNameFunctions["PCI"] = function(category) { return util.getFirstMatchGroup(/(Requirement.*?)\./, category); } 
extListUtil.groupNameFunctions["NIST"] = function(category) { 
	var shortgroup = util.getFirstMatchGroup(/(.*?)-.*/, category); /* used non-greedy matching(*?) to deal with IA-8 */
	var fullname = nistControl[shortgroup];  // NIST is a special case since the groupname derived from category only gives us shortform
	var expanded = util.isDefined(fullname) ?  fullname+' ('+shortgroup+')'  : shortgroup ;	
	return expanded;
} 

/**
 * Get the group name for the given category
 */
extListUtil.getExternalCategoryGroupName = function( listGroup, category ) {
	return util.returnFunctionValueOrDefault(extListUtil.groupNameFunctions[listGroup], category, null);
}

/**
 * The functions in this array will return the short name for the given category
 */
extListUtil.shortNameFunctions = new Object();
extListUtil.shortNameFunctions["NIST"] = function(category) { return util.getFirstMatchGroup(/([A-Z]{2}-[0-9]*) .*/, category); }
extListUtil.shortNameFunctions["OWASP"] = function(category) { return util.getFirstMatchGroup(/(A[1-9]|A10|M[1-9]|M10) .*/, category); } // handles both normal owasp and mobile
extListUtil.shortNameFunctions["SANS"] = function(category) { return util.getFirstMatchGroup(/.* - (CWE ID .*)/, category); }
extListUtil.shortNameFunctions["PCI"] = function(category) { return category.replace("Requirement","Req."); }
extListUtil.shortNameFunctions["STIG"] = function(category) { return util.getFirstMatchGroup(/(AP.*) CAT .*/, category); }

/**
 * Get the short name for the given category
 */
extListUtil.getExternalCategoryShortName = function( listGroup, category ) {
		return util.returnFunctionValueOrDefault(extListUtil.shortNameFunctions[listGroup], category, category);
}

/**
 * The functions in this array will return the long name for the given category
 */
extListUtil.longNameFunctions = new Object();
extListUtil.longNameFunctions["FISMA"] = function(category) {
	switch ( category ) {
		case 'AC': return 'Access Control';
		case 'AU': return 'Audit and Accountability';
		case 'CM': return 'Configuration Management';
		case 'IA': return 'Identification and Authentication';
		case 'MP': return 'Media Protection';
		case 'SC': return 'System and Communications Protection';
		case 'SI': return 'System and Information Integrity ';
		default: return category;
	}
}

/**
 * Get the long name for the given category
 */
extListUtil.getExternalCategoryLongName = function( listGroup, category ) {
		return util.returnFunctionValueOrDefault(extListUtil.longNameFunctions[listGroup], category, category);
}

// actual definition of nistControls 
nistControl = {
		  // the following are Security Controls
		  "AC": "Access Control",
		  "AT"  : "Awareness and Training" ,
		  "AU" : "Audit and Accountability",
		  "CA"  : "Security Assessment and Authorization" ,
		  "CM"  : "Configuration Management" ,
		  "CP"  : "Contingency Planning" ,
		  "IA"  : "Identification and Authentication" ,
		  "IR"  : "Incident Response" ,
		  "MA"  : "Maintenance" ,
		  "MP"  : "Media Protection" ,
		  "PE"  : "Physical and Environmental Protection" ,
		  "PL"  : "Planning" ,
		  "PS"  : "Personnel Security" ,
		  "RA"  : "Risk Assessment" ,
		  "SA"  : "System and Services Acquisition" ,
		  "SC"  : "System and Communications Protection" ,
		  "SI"  : "System and Information Integrity" ,
		  "PM"  : "Program Management" ,
		  // the following are Privacy Controls
		  "AP"  : "Authority and Purpose" ,
		  "AR"  : "Accountability, Audit, and Risk Management" ,
		  "DI"  : "Data Quality and Integrity" ,
		  "DM"  : "Data Minimization and Retention" ,
		  "IP"  : "Individual Participation and Redress" ,
		  "SE"  : "Security" ,
		  "TR"  : "Transparency" ,
		  "UL"  : "Use Limitation" 
};