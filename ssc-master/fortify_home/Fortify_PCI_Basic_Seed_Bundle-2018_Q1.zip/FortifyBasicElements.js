/**
 This file defines various utility functions and objects that may be useful for 
 implementing report designs. All functions and objects are made available via
 the JavaScript object named 'util'. Most report elements will be able to reference
 this util object directly. However, some report elements like charts have there 
 own scripting context. In order to access the util object from charts and similar
 elements, something like the following can be used:
 var util = icsc.getExternalContext().getScriptable().evaluate('util');
*/
util = new Object();

/**
 This function will return true if the given value is defined,
 false otherwise.
*/
util.isDefined = function(value) {
	return ( typeof(value) != 'undefined' && value != null );
}

/**
 This function will return true if the given value is defined
 and is not blank (i.e. if it contains non-whitespace characters).
 Otherwise false is returned. 
*/
util.isNotBlank = function(value) {
	return util.isDefined(value) && value.replace(/^\s\s*/,'').replace(/\s\s*$/,'')!='';
}

/**
 * This function returns the first matched regex group on str
 */
util.getFirstMatchGroup = function( regex, str ) {
	var matches = regex.exec(str);
	if ( matches!=null && matches.length>=1 ) {
		return matches[1];
    } else {
    	return null;
    }
}

/**
 * This function will execute the given function with the given parameter.
 * If the given function parameter is not a JavaScript function (for
 * example undefined or null), then the given default value will be returned.
 */
util.returnFunctionValueOrDefault = function( f, param, def ) {
	if ( typeof f == "function" ) {
		return f(param);
	} else { 
		return def;
	}
}

/**
 Get the text expression for the given element. If the given element
 contains a valueExpr property, the value of this property is returned.
 Otherwise, if the given element contains a text property, the text
 property value is returned surrounded by quotes (to make it a valid
 expression). If none of these properties is defined, null is returned.
*/
util.getElementTextExpression = function(elt) {
	var result = null;
	if ( util.isDefined(elt.valueExpr) ) {
		result = elt.valueExpr;
	} else if ( util.isDefined(elt.text) ) {
		result = "'"+elt.text+"'";
	} 
	return result;
}

/**
 This function will update the given BIRT property on the given 
 element if the property has not yet been defined. If the property
 is already defined, it will not be updated.
*/
util.updatePropertyIfUndefined = function(elt, prop, value) {
	if ( util.isDefined(elt[prop]) ) {
		util.log("Property "+prop+" for "+elt+" already defined: "+elt[prop]);
	} else {
		if ( !util.isDefined(value) ) {
			util.log("Not updating property "+prop+" for "+elt+"; no valid value found");
		} else {
			elt[prop] = value;
			util.log("Updated property "+prop+" for "+elt+": "+elt[prop]);
		}
	}
}

/**
 This function will set the BIRT 'Table of Contents' property for the given element
 if no TOC property has been defined yet. The TOC property will be set to the
 text expression defined by the given element. If the element is contained in a
 table/list group, the 'Table of Contents' property is set on the table/list group
 instead of the element itself. 
*/
util.addTOC = function(elt) {
	var parent = elt.getParent();
	if ( util.isDefined(parent) && parent.getClass().getSimpleName().endsWith("Group") ) {
		// If this heading is defined inside a group, the PDF bookmarks are organized better
		// when the tocExpression is set on the group instead of the section header.
		util.log("Adding TOC for "+elt+" on parent group");
		util.updatePropertyIfUndefined(parent, 'tocExpression', util.getElementTextExpression(elt));
	} else {
		util.log("Adding TOC for "+elt);
		util.updatePropertyIfUndefined(elt, 'tocExpression', util.getElementTextExpression(elt));
	}
};

/**
 This function will set the BIRT 'Bookmark' property for the given element
 if no bookmark property has been defined yet. The bookmark property will be set to the
 text expression defined by the given element.
*/
util.addBookmark = function(elt) {
	util.log("Adding bookmark for "+elt);
	util.updatePropertyIfUndefined(elt, 'bookmark', util.getElementTextExpression(elt));
};

/**
 This function will set the BIRT 'Table of Contents' and 'Bookmark' properties
 for the given element if these properties have not yet been defined. See 
 util.addBookmark and util.addTOC for more information.
*/
util.addBookmarkAndTOC = function(elt) {
	util.addTOC(elt);
	util.addBookmark(elt);
}

/**
 This function defines a Logger object that can be used for debug logging.
 Logs are written to the file specified by the ReportLogFile report parameter.
 If this parameter is not defined, no log will be written. Scripts that want
 to output logging information should not use this object directly, but instead
 call the util.log(msg) function.
*/
util.Logger = function() {
	try {
		var logFile = params["ReportLogFile"].value;
		this.fileWriter = new java.io.FileWriter(logFile, true);
		this.out = new java.io.PrintWriter(this.fileWriter);
	} catch(ignore) {}
	this.log = function(msg) {
		if ( typeof(this.out) != "undefined" ) {
			this.out.println("["+new java.util.Date().toString()+"]"+msg);
			this.out.flush();
		}
	};
};
util.Log = new util.Logger();
util.log = function(msg) {
	util.Log.log(msg);
}

/**
 This function removes the sorting prefix from the data set for the given
 chart series. In some cases, BIRT doesn't allow custom sorting on chart
 series. As a work-around, report developers can prefix the chart series
 with sorting information (i.e. 0001!<Series Value>), and call this function
 in the afterDataSetFilled() event handler. This will allow the series to
 be sorted based on the sorting prefix, but still showing only the actual
 series values on the chart.
*/
util.removeSortPrefix = function( series, dataSet )
{
	importPackage( Packages.org.eclipse.birt.chart.model.data.impl );
	
	util.Log.log("removeSortPrefix() dataSet before: "+dataSet.getValues().join(","));
	if( series.getClass().getName().endsWith(".SeriesImpl") ){
		var list = dataSet.getValues();
		var narray1 = new java.util.ArrayList( list.length );
	    for ( i=0; i < list.length; i++)
	    {
			narray1.add(list[i].split("!")[1]);
	    }
    
		series.setDataSet(TextDataSetImpl.create( narray1 ));
		util.Log.log("removeSortPrefix() dataSet after: "+narray1);
	}
};

/**
 This method will generate an IN-clause for the given column name
 and IN arguments string. The IN arguments string will be split using
 the given separator (using comma as a separator if no separator given).
 If the number of IN arguments exceeds the chunk size (100), then
 multiple IN-clauses will be generated, separated by OR. For example,
 if columnName is 'TEST', and inArgsStr contains numbers 1-975 separated
 by a comma, then the output will be something like
 (TEST IN (1,...,100) OR TEST IN (101,...,200) OR ... OR TEST IN (901,...,975))
 This approach will prevent errors on some databases if there are too many elements
 in an IN-clause.
*/
util.getInClause = function(columnName, inArgsStr, separator) {
	var chunkSize = 100;
	// Remove surrounding brackets/parenthesis, then split the inArgsStr
	inArgsStr += ""; // Convert to JavaScript string even if original string came from Java operations(bug 41956)
	var inArgs = inArgsStr.replace(/^[\(\[]|[\)\]]$/g,'').split(util.isDefined(separator)?separator:',');
	var result = "";
	var multiClause = false;
	var i,j;
	// Create IN-clause for individual chunks
	for ( i = 0, j = inArgs.length ; i < j ; i += chunkSize ) {
		var chunk = inArgs.slice(i, i+chunkSize);
		if ( chunk.length > 0 ) {
			if ( result != "" ) { result += " OR "; multiClause=true; }
			result += columnName + " IN (" + chunk.join(',') + ")";
		}
	}
	// Add opening and closing parenthesis if we have an ORed expression
	if ( result != "" && multiClause==true ) result = "("+result+")";
	return result;
}

/**
 This function will generate an IN-clause for the given column name,
 using the project version id's as specified by the projectversionids
 parameter.
*/
util.getProjectVersionIdsInClause = function(columnName) {
	return util.getInClause(columnName, params["projectversionids"], ",");
}

/**
 This function will evaluate all expressions surrounded by {{ and }} 
 using the JavaScript eval function.
*/
util.evaluateExpressions = function(text) {
	text += ''; // Append empty string to convert to JavaScript string if necessary
	return text.replace(/\{\{(.+?)\}\}/g, function(match, p1) {
		return eval(p1);
	});
}

/**
 This function will evaluate all expressions surrounded by {{ and }} 
 contained in the query text for the given data set using the 
 JavaScript eval function. This function is usually called in the
 beforeOpenHandler for a data set, and allows for embedding JavaScript
 expressions inside the query text. For example, together with the 
 util.getInClause() function, this allows you to dynamically build
 IN-clauses.
*/
util.evaluateQueryTextExpressions = function(dataSet) {
	dataSet.queryText = util.evaluateExpressions(dataSet.queryText);
	util.log("evaluateQueryTextExpressions: new dataSet.queryText:\n"+dataSet.queryText);
}

/**
 RGBColor is a utility function/class to handle RGB colors
*/
util.RGBColor = function(color_string)
{
    this.ok = false;

    // strip any leading #
    if (color_string.charAt(0) == '#') { // remove # if any
        color_string = color_string.substr(1);
    }

    color_string = color_string.replace(/ /g,'');
    color_string = color_string.toLowerCase();

    // before getting into regexps, try simple matches
    // and overwrite the input
    var simple_colors = {
        aliceblue: 'f0f8ff',
        antiquewhite: 'faebd7',
        aqua: '00ffff',
        aquamarine: '7fffd4',
        azure: 'f0ffff',
        beige: 'f5f5dc',
        bisque: 'ffe4c4',
        black: '000000',
        blanchedalmond: 'ffebcd',
        blue: '0000ff',
        blueviolet: '8a2be2',
        brown: 'a52a2a',
        burlywood: 'deb887',
        cadetblue: '5f9ea0',
        chartreuse: '7fff00',
        chocolate: 'd2691e',
        coral: 'ff7f50',
        cornflowerblue: '6495ed',
        cornsilk: 'fff8dc',
        crimson: 'dc143c',
        cyan: '00ffff',
        darkblue: '00008b',
        darkcyan: '008b8b',
        darkgoldenrod: 'b8860b',
        darkgray: 'a9a9a9',
        darkgreen: '006400',
        darkkhaki: 'bdb76b',
        darkmagenta: '8b008b',
        darkolivegreen: '556b2f',
        darkorange: 'ff8c00',
        darkorchid: '9932cc',
        darkred: '8b0000',
        darksalmon: 'e9967a',
        darkseagreen: '8fbc8f',
        darkslateblue: '483d8b',
        darkslategray: '2f4f4f',
        darkturquoise: '00ced1',
        darkviolet: '9400d3',
        deeppink: 'ff1493',
        deepskyblue: '00bfff',
        dimgray: '696969',
        dodgerblue: '1e90ff',
        feldspar: 'd19275',
        firebrick: 'b22222',
        floralwhite: 'fffaf0',
        forestgreen: '228b22',
        fuchsia: 'ff00ff',
        gainsboro: 'dcdcdc',
        ghostwhite: 'f8f8ff',
        gold: 'ffd700',
        goldenrod: 'daa520',
        gray: '808080',
        green: '008000',
        greenyellow: 'adff2f',
        honeydew: 'f0fff0',
        hotpink: 'ff69b4',
        indianred : 'cd5c5c',
        indigo : '4b0082',
        ivory: 'fffff0',
        khaki: 'f0e68c',
        lavender: 'e6e6fa',
        lavenderblush: 'fff0f5',
        lawngreen: '7cfc00',
        lemonchiffon: 'fffacd',
        lightblue: 'add8e6',
        lightcoral: 'f08080',
        lightcyan: 'e0ffff',
        lightgoldenrodyellow: 'fafad2',
        lightgrey: 'd3d3d3',
        lightgreen: '90ee90',
        lightpink: 'ffb6c1',
        lightsalmon: 'ffa07a',
        lightseagreen: '20b2aa',
        lightskyblue: '87cefa',
        lightslateblue: '8470ff',
        lightslategray: '778899',
        lightsteelblue: 'b0c4de',
        lightyellow: 'ffffe0',
        lime: '00ff00',
        limegreen: '32cd32',
        linen: 'faf0e6',
        magenta: 'ff00ff',
        maroon: '800000',
        mediumaquamarine: '66cdaa',
        mediumblue: '0000cd',
        mediumorchid: 'ba55d3',
        mediumpurple: '9370d8',
        mediumseagreen: '3cb371',
        mediumslateblue: '7b68ee',
        mediumspringgreen: '00fa9a',
        mediumturquoise: '48d1cc',
        mediumvioletred: 'c71585',
        midnightblue: '191970',
        mintcream: 'f5fffa',
        mistyrose: 'ffe4e1',
        moccasin: 'ffe4b5',
        navajowhite: 'ffdead',
        navy: '000080',
        oldlace: 'fdf5e6',
        olive: '808000',
        olivedrab: '6b8e23',
        orange: 'ffa500',
        orangered: 'ff4500',
        orchid: 'da70d6',
        palegoldenrod: 'eee8aa',
        palegreen: '98fb98',
        paleturquoise: 'afeeee',
        palevioletred: 'd87093',
        papayawhip: 'ffefd5',
        peachpuff: 'ffdab9',
        peru: 'cd853f',
        pink: 'ffc0cb',
        plum: 'dda0dd',
        powderblue: 'b0e0e6',
        purple: '800080',
        red: 'ff0000',
        rosybrown: 'bc8f8f',
        royalblue: '4169e1',
        saddlebrown: '8b4513',
        salmon: 'fa8072',
        sandybrown: 'f4a460',
        seagreen: '2e8b57',
        seashell: 'fff5ee',
        sienna: 'a0522d',
        silver: 'c0c0c0',
        skyblue: '87ceeb',
        slateblue: '6a5acd',
        slategray: '708090',
        snow: 'fffafa',
        springgreen: '00ff7f',
        steelblue: '4682b4',
        tan: 'd2b48c',
        teal: '008080',
        thistle: 'd8bfd8',
        tomato: 'ff6347',
        turquoise: '40e0d0',
        violet: 'ee82ee',
        violetred: 'd02090',
        wheat: 'f5deb3',
        white: 'ffffff',
        whitesmoke: 'f5f5f5',
        yellow: 'ffff00',
        yellowgreen: '9acd32'
    };
    for (var key in simple_colors) {
        if (color_string == key) {
            color_string = simple_colors[key];
        }
    }
    // emd of simple type-in colors

    // array of color definition objects
    var color_defs = [
        {
            re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,
            example: ['rgb(123, 234, 45)', 'rgb(255,234,245)'],
            process: function (bits){
                return [
                    parseInt(bits[1]),
                    parseInt(bits[2]),
                    parseInt(bits[3])
                ];
            }
        },
        {
            re: /^(\w{2})(\w{2})(\w{2})$/,
            example: ['#00ff00', '336699'],
            process: function (bits){
                return [
                    parseInt(bits[1], 16),
                    parseInt(bits[2], 16),
                    parseInt(bits[3], 16)
                ];
            }
        },
        {
            re: /^(\w{1})(\w{1})(\w{1})$/,
            example: ['#fb0', 'f0f'],
            process: function (bits){
                return [
                    parseInt(bits[1] + bits[1], 16),
                    parseInt(bits[2] + bits[2], 16),
                    parseInt(bits[3] + bits[3], 16)
                ];
            }
        }
    ];

    // search through the definitions to find a match
    for (var i = 0; i < color_defs.length; i++) {
        var re = color_defs[i].re;
        var processor = color_defs[i].process;
        var bits = re.exec(color_string);
        if (bits) {
            channels = processor(bits);
            this.r = channels[0];
            this.g = channels[1];
            this.b = channels[2];
            this.ok = true;
        }

    }

    // validate/cleanup values
    this.r = (this.r < 0 || isNaN(this.r)) ? 0 : ((this.r > 255) ? 255 : this.r);
    this.g = (this.g < 0 || isNaN(this.g)) ? 0 : ((this.g > 255) ? 255 : this.g);
    this.b = (this.b < 0 || isNaN(this.b)) ? 0 : ((this.b > 255) ? 255 : this.b);

    // some getters
    this.toRGB = function () {
        return 'rgb(' + this.r + ', ' + this.g + ', ' + this.b + ')';
    }
    this.toHex = function () {
        var r = this.r.toString(16);
        var g = this.g.toString(16);
        var b = this.b.toString(16);
        if (r.length == 1) r = '0' + r;
        if (g.length == 1) g = '0' + g;
        if (b.length == 1) b = '0' + b;
        return '#' + r + g + b;
    }
    this.getContrastingBlackOrWhiteHex = function () {
    	var result = "#ffffff"; // White color for dark backgrounds
    	// Counting the perceptive luminance - human eye favors green color... 
		var a = 1 - ( 0.299 * this.r + 0.587 * this.g + 0.114 * this.b)/255;

		if (a < 0.5) result = "#000000"; // Black color for light backgrounds
		return result;
    }
};

/**
 Based on the given separator, this function splits the given colorAndLabelStr into a 
 simple text label and its corresponding color. Label and color are available via
 the label and rgbColor properties respectively. 
*/
util.LabelAndRGBColor = function(colorAndLabelStr, separator) {
	var str = colorAndLabelStr+""; // convert to JavaScript string
	var elts = str.split(separator);
	this.label = elts[1];
	this.rgbColor = new util.RGBColor(elts[0]);
};